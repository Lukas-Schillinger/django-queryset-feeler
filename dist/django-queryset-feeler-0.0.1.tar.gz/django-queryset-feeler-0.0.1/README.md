[![This is an image](https://img.shields.io/pypi/v/pyhmer.svg?style=flat-square)](https://pypi.python.org/pypi/django-queryset-feeler)

# django-queryset-feeler

### About


